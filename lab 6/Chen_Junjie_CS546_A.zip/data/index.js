const bands = require('./bands');
const albums = require('./albums');

module.exports = { bands, albums };
