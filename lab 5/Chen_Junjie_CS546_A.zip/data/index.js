const userApi = require('./userApi');

module.exports = userApi;
